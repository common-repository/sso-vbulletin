=== SSO vBulletin ===

How to install and setup SSO vBulletin solution on vBulletin side:

	1. Disable all vBulletin plugins which are anticipating in Registration/Login processes.

	2. Install SSO vBulletin product on vBulletin (see #2 of Installation chapter in main readme file).

	3. Change vBulletin Login Link:
		Log in as vBulletin Administrator → Open Styles and Templates → Add next changes to the current theme:
		Comment or remove next lines out in template `header`: <form id="navbar_loginform" ... till </form>.
		Paste the link right after the commented out form: <a rel="nofollow" class="guest-login" href="{vb:raw vboptions.wvsso_login_url}">Login</a>
		(or simply replace all code with the last link of this form).

	4. Specify all redirection link in SSO vBulletin plugin (see #2 of Configuration chapter in main readme file).

	5. Put  User Registration Options -> Username Reuse Delay → 0 (vBulletin→Settings→User Registration Options→ Username Reuse Delay→ 0→ this setting will enable the possibility to change usernames and remove accounts correctly (users will be able to re-register account with already registered credentials).

More info about the plugin - https://www.extreme-idea.com/